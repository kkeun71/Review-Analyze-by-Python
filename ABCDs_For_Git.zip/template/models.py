
from django.db import models

# Create your models here.
class Craw(models.Model): # Craw 테이블 정보
    itemname = models.TextField()
    url = models.TextField()
    review = models.TextField()
    img_url = models.TextField(blank=True, null=True)
    star = models.TextField()
    category = models.CharField(max_length=50)
    re_star = models.CharField(max_length=15)

    class Meta:
        managed = False
        db_table = 'craw'

class Keyword(models.Model): # Keyword 테이블 정보
    itemname = models.TextField()
    url = models.TextField()
    keyword = models.TextField()
    img_url = models.TextField()
    star = models.TextField(blank=True, null=True)
    counts = models.TextField()
    category = models.CharField(max_length=50)
    positive = models.CharField(max_length=10)
    negative = models.CharField(max_length=10)

    class Meta:
        managed = False
        db_table = 'keyword'