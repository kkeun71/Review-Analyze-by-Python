from .img_search import img_se
from .pr_list import previous_search_list

# 반환받은 이미지 정보를 통해 이전 검색리스트에 사용할 정보 추출후 서버에 반환하는 함수
def first_play():
    img_list = previous_search_list() # 이미지 리스트 받음
    result_list = img_se(img_list[0]) # 첫번째 이미지 
    return result_list

def second_play():
    img_list = previous_search_list()
    result_list = img_se(img_list[1])# 두번째 이미지 
    return result_list

def third_play():
    img_list = previous_search_list()
    result_list = img_se(img_list[2])# 세번째 이미지 
    return result_list

def fourth_play():
    img_list = previous_search_list()
    result_list = img_se(img_list[3])# 네번째 이미지 
    return result_list
