import re

def clean_text(inputString): # 문자열 내에 특수 문자 제거 후 공백을 추가하여 문자열 리스트 생성
    text_rmv = re.sub('[-=+,#/\?:^.@*\"※~ㆍ!』‘|\(\)\[\]`\'…》\”\“\’·_]', ' ', inputString)
    text_rmv = text_rmv.replace("\\n","")
    text_rmv = ' '.join(text_rmv.split())
    return text_rmv