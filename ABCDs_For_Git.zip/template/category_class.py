import os
from django.conf import settings

def category_clean_text(inputString):
    text_rmv = inputString
    text_rmv = text_rmv.replace("\\n","")
    text_rmv = ' '.join(text_rmv.split())
    return text_rmv

def category_load(text):

    global category
    
    # 현재 디렉토리 경로 변수에 저장
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    ##### 크롤링 된 카테고리를 분류한 대분류 카테고리에 맞게 변경 #####
    acc = open(BASE_DIR+"/template/category/acc.txt", "r", encoding="utf-8")
    acc = acc.readlines()
    acc = list(map(category_clean_text, acc))

    baby = open(BASE_DIR+"/template/category/baby.txt", "r", encoding="utf-8")
    baby = baby.readlines()
    baby = list(map(category_clean_text, baby))

    beauty = open(BASE_DIR+"/template/category/beauty.txt", "r", encoding="utf-8")
    beauty = beauty.readlines()
    beauty = list(map(category_clean_text, beauty))

    book_music = open(BASE_DIR+"/template/category/book_music.txt", "r", encoding="utf-8")
    book_music = book_music.readlines()
    book_music = list(map(category_clean_text, book_music))

    car = open(BASE_DIR+"/template/category/car.txt", "r", encoding="utf-8")
    car = car.readlines()
    car = list(map(category_clean_text, car))

    cloth = open(BASE_DIR+"/template/category/cloth.txt", "r", encoding="utf-8")
    cloth = cloth.readlines()
    cloth = list(map(category_clean_text, cloth))

    digital = open(BASE_DIR+"/template/category/digital.txt", "r", encoding="utf-8")
    digital = digital.readlines()
    digital = list(map(category_clean_text, digital))

    food = open(BASE_DIR+"/template/category/food.txt", "r", encoding="utf-8")
    food = food.readlines()
    food = list(map(category_clean_text, food))

    health = open(BASE_DIR+"/template/category/health.txt", "r", encoding="utf-8")
    health = health.readlines()
    health = list(map(category_clean_text, health))

    hobby = open(BASE_DIR+"/template/category/hobby.txt", "r", encoding="utf-8")
    hobby = hobby.readlines()
    hobby = list(map(category_clean_text, hobby))

    home = open(BASE_DIR+"/template/category/home.txt", "r", encoding="utf-8")
    home = home.readlines()
    home = list(map(category_clean_text, home))

    life = open(BASE_DIR+"/template/category/life.txt", "r", encoding="utf-8")
    life = life.readlines()
    life = list(map(category_clean_text, life))

    office = open(BASE_DIR+"/template/category/office.txt", "r", encoding="utf-8")
    office = office.readlines()
    office = list(map(category_clean_text, office))

    pet = open(BASE_DIR+"/template/category/pet.txt", "r", encoding="utf-8")
    pet = pet.readlines()
    pet = list(map(category_clean_text, pet))

    sport = open(BASE_DIR+"/template/category/sport.txt", "r", encoding="utf-8")
    sport = sport.readlines()
    sport = list(map(category_clean_text, sport))

    trip = open(BASE_DIR+"/template/category/trip.txt", "r", encoding="utf-8")
    trip = trip.readlines()
    trip = list(map(category_clean_text, trip))

    # 변경된 카테고리를 반환 (DB INSERT에 사용됨)
    if text in acc:
        category = "악세서리"
        return category

    elif text in baby:
        category = "출산/유아동"
        return category

    elif text in beauty:
        category = "뷰티"
        return category

    elif text in book_music:
        category = "도서/음반/DVD"
        return category

    elif text in car:
        category = "자동차용품"
        return category

    elif text in cloth:
        category = "패션의류/잡화"
        return category

    elif text in digital:
        category = "가전디지털"
        return category

    elif text in food:
        category = "식품"
        return category

    elif text in health:
        category = "헬스/건강식품"
        return category

    elif text in hobby:
        category = "완구/취미"
        return category

    elif text in home:
        category = "홈인테리어"
        return category

    elif text in life:
        category = "생활용품"
        return category

    elif text in office:
        category = "문구/오피스"
        return category

    elif text in pet:
        category = "반려동물용품"
        return category

    elif text in sport:
        category = "스포츠/레저"
        return category

    elif text in trip:
        category = "여행/티켓"
        return category