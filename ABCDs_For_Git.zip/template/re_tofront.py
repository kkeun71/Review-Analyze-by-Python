# 추천 시스템을 서버에 표시해주기 위해 상품 이미지와 상품명을 추출해 반환해주는 함수(총 8개)
def refront_1(df):
    df = df.reset_index(drop=True)
    img_url = df["img_url"]
    itemname = df["itemname"]
    
    return itemname[0], img_url[0]

def refront_2(df):
    df = df.reset_index(drop=True)
    img_url = df["img_url"]
    itemname = df["itemname"]

    return itemname[1], img_url[1]

def refront_3(df):
    df = df.reset_index(drop=True)
    img_url = df["img_url"]
    itemname = df["itemname"]

    return itemname[2], img_url[2]

def refront_4(df):
    df = df.reset_index(drop=True)
    img_url = df["img_url"]
    itemname = df["itemname"]

    return itemname[3], img_url[3]

def refront_5(df):
    df = df.reset_index(drop=True)
    img_url = df["img_url"]
    itemname = df["itemname"]

    return itemname[4], img_url[4]

def refront_6(df):
    df = df.reset_index(drop=True)
    img_url = df["img_url"]
    itemname = df["itemname"]

    return itemname[5], img_url[5]

def refront_7(df):
    df = df.reset_index(drop=True)
    img_url = df["img_url"]
    itemname = df["itemname"]

    return itemname[6], img_url[6]

def refront_8(df):
    df = df.reset_index(drop=True)
    img_url = df["img_url"]
    itemname = df["itemname"]

    return itemname[7], img_url[7]