from django.shortcuts import render
import pymysql
from .forms import CoverForm
from .craw import crawling 
from django.shortcuts import redirect
from .ke_def import keyword
from .fusioncharts import FusionCharts
from collections import OrderedDict
import time
from .word_count import count
from .presence_test import pre_test
from .pr_photo import first_play, second_play, third_play, fourth_play
from .re_tofront import refront_1, refront_2, refront_3, refront_4, refront_5, refront_6, refront_7, refront_8
import os
from django.http import HttpResponse
from .re_def import recommendation_system, category_df
from pymysql.constants import CLIENT
from .clean_text import clean_text
from konlpy.tag import Okt
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
import re # 정규식을 사용하기 위해 re 모듈을 임포트

okt = Okt()
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# tfv모델 학습 구간
train_df = pd.read_excel(BASE_DIR + '\\template\\emotional.xlsx')

# 데이터 확인
# print(train_df.head())

# text 컬럼이 non-null인 샘플만 train_df에 다시 저장
train_df = train_df[train_df['review'].notnull()]


# ‘ㄱ ~‘힣’까지의 문자를 제외한 나머지는 공백으로 치환, 영문: a-z| A-Z
train_df['review'] = train_df['review'].apply(lambda x : re.sub(r'[^ ㄱ-ㅣ가-힣]+', " ", x))
# print(train_df.head())

# Train용 데이터셋의 정보를 재확인
text = train_df['review'] # 시리즈 객체로 저장
score = train_df['re_star']

train_x, test_x, train_y, test_y = train_test_split(text, score , test_size=0.2, random_state=0)
# print(len(train_x), len(train_y), len(test_x), len(test_y))

tfv = TfidfVectorizer(tokenizer=okt.morphs, ngram_range=(1,2), min_df=3, max_df=0.9)
tfv.fit(train_x)

# 학습 구간 끝

conn = pymysql.connect(host='localhost', # 데이터 베이스 연결
                    user='root',
                    password='1234',
                    db='abcds',
                    charset='utf8mb4',
                    autocommit=True,
                    client_flag = CLIENT.MULTI_STATEMENTS,
                    )

mycursor = conn.cursor() # 커서 설정

def home(request): # 크롤링 함수
    form = CoverForm() 
    ctx = {
        'form':form,
    }
    global photo_1, photo_2, photo_3, photo_4, itemname_1, itemname_2, itemname_3, itemname_4

    fisrt_result = first_play()
    photo_1 = fisrt_result[3]
    itemname_1 = fisrt_result[0]

    second_result = second_play()
    photo_2 = second_result[3]
    itemname_2 = second_result[0]

    third_result = third_play()
    photo_3 = third_result[3]
    itemname_3 = third_result[0]

    fourth_result = fourth_play()
    photo_4 = fourth_result[3]
    itemname_4 = fourth_result[0]
    
    if request.method == "POST": 
        form = CoverForm(request.POST) # 입력받은 url 데이터 변수 저장
        global itemname
        global test_itemname
        global test
        global product_url
        product_url = form.data.__getitem__('url')
        test = pre_test(product_url)

        time.sleep(1)
        if test == False:
            test_itemname = crawling(form.data.__getitem__('url')) # 크롤링 함수에 파라미터로 url 전달
            itemname = test_itemname
            return redirect('/search')
        elif test == True:
            check_sql = "select itemname from keyword where url = '{}'".format(product_url)
            mycursor.execute(check_sql)
            check_result = mycursor.fetchone() #가끔 itemname 못불러오는데 오류 수정필요!
            test_itemname = str(check_result[0])
            itemname = test_itemname
            return redirect('/search')

    return render(request, 'post/index.html', {"form" : ctx,
                                               "photo_1" : photo_1, "itemname_1" : itemname_1,
                                               "photo_2" : photo_2, "itemname_2" : itemname_2,
                                               "photo_3" : photo_3, "itemname_3" : itemname_3,
                                               "photo_4" : photo_4, "itemname_4" : itemname_4})

def search(request):
    if itemname is None:
        return HttpResponse(
            "<script>alert('리뷰가 없습니다!');location.href='/';</script>")
    else :
        if test == True:
            time.sleep(1)
            graph_sql = "select keyword,counts from keyword where url = '{}'".format(product_url)
            mycursor.execute(graph_sql)
            graph_source = mycursor.fetchall()[0]
            word = graph_source[0].split()
            counts = graph_source[1].split()

            dataSource = OrderedDict() # 여기부터
    
            chartConfig = OrderedDict()
            chartConfig["caption"] = "상품 키워드 분석 결과"
            chartConfig["subCaption"] = "상품명 : " + itemname
            chartConfig["xAxisName"] = "키워드"
            chartConfig["yAxisName"] = ""
            chartConfig["numberSuffix"] = "개"
            chartConfig["theme"] = "fusion" 

            dataSource["chart"] = chartConfig
            dataSource["data"] = []

            for i in range(len(word)) :
                dataSource["data"].append({"label": word[i], "value": counts[i]})

            column2D = FusionCharts("column2d", "myFirstChart", "650", "650", "myFirstchart-container", "json", dataSource)  
            try:
        
                photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
                mycursor.execute(photo_sql)
                photo = mycursor.fetchall()[0][0]
                star = float(mycursor.fetchall()[0][1])

            except:
        
                photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
                mycursor.execute(photo_sql)
                photo = mycursor.fetchone()[0]
                star = float(mycursor.fetchall()[0][1])

            count(itemname)
            category_text = category_df(itemname)
            result_df = recommendation_system(itemname,category_text)

            emotional_sql = 'select positive,negative from keyword where itemname = "{}" '.format(itemname) 
            mycursor.execute(emotional_sql)
            pos_neg_list = mycursor.fetchone()
            positive, negative = (pos_neg_list[0], pos_neg_list[1])

            global re_name1, re_name2, re_name3, re_name4, re_name5, re_name6, re_name7, re_name8

            re_name1, re_photo1 = refront_1(result_df)
            re_name2, re_photo2 = refront_2(result_df)
            re_name3, re_photo3 = refront_3(result_df)
            re_name4, re_photo4 = refront_4(result_df)
            re_name5, re_photo5 = refront_5(result_df)
            re_name6, re_photo6 = refront_6(result_df)
            re_name7, re_photo7 = refront_7(result_df)
            re_name8, re_photo8 = refront_8(result_df)

            re_itemname = clean_text(itemname)

            return render(request, 'post/search.html', {"photo" : photo, "itemname" : itemname, "output": column2D.render(),
                                                "re_name1" : re_name1, "re_photo1" : re_photo1, 
                                                "re_name2" : re_name2, "re_photo2" : re_photo2,
                                                "re_name3" : re_name3, "re_photo3" : re_photo3,
                                                "re_name4" : re_name4, "re_photo4" : re_photo4,
                                                "re_name5" : re_name5, "re_photo5" : re_photo5,
                                                "re_name6" : re_name6, "re_photo6" : re_photo6,
                                                "re_name7" : re_name7, "re_photo7" : re_photo7,
                                                "re_name8" : re_name8, "re_photo8" : re_photo8,
                                                "star" : star,
                                                "positive" : positive,
                                                "negative" : negative,
                                                "re_itemname" : re_itemname}) 
        
        if test == False:
            keyword(itemname,tfv)
        
            time.sleep(1)
            graph_sql = "select keyword,counts from keyword where itemname = '{}'".format(itemname)
            mycursor.execute(graph_sql)
            graph_source = mycursor.fetchall()[0]
            word = graph_source[0].split()
            counts = graph_source[1].split()

            dataSource = OrderedDict() # 여기부터
    
            chartConfig = OrderedDict()
            chartConfig["caption"] = "상품 키워드 분석 결과"
            chartConfig["subCaption"] = "상품명 : " + itemname
            chartConfig["xAxisName"] = "키워드"
            chartConfig["yAxisName"] = ""
            chartConfig["numberSuffix"] = "개"
            chartConfig["theme"] = "fusion" 

            dataSource["chart"] = chartConfig
            dataSource["data"] = []

            for i in range(len(word)) :
                dataSource["data"].append({"label": word[i], "value": counts[i]})

            column2D = FusionCharts("column2d", "myFirstChart", "650", "650", "myFirstchart-container", "json", dataSource)
            try:
        
                photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
                mycursor.execute(photo_sql)
                photo = mycursor.fetchall()[0][0]
                star = float(mycursor.fetchall()[0][1])


            except:
                photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
                mycursor.execute(photo_sql)
                photo = mycursor.fetchone()[0]
                star = float(mycursor.fetchall()[0][1])


            count(itemname)
            category_text = category_df(itemname)
            result_df = recommendation_system(itemname,category_text)
            
            emotional_sql = 'select positive, negative from keyword where itemname = "{}"'.format(itemname) #######
            mycursor.execute(emotional_sql)
            pos_neg_list = mycursor.fetchone()
            positive, negative = (pos_neg_list[0], pos_neg_list[1])


            re_name1, re_photo1 = refront_1(result_df)
            re_name2, re_photo2 = refront_2(result_df)
            re_name3, re_photo3 = refront_3(result_df)
            re_name4, re_photo4 = refront_4(result_df)
            re_name5, re_photo5 = refront_5(result_df)
            re_name6, re_photo6 = refront_6(result_df)
            re_name7, re_photo7 = refront_7(result_df)
            re_name8, re_photo8 = refront_8(result_df)
            
            re_itemname = clean_text(itemname)

            return render(request, 'post/search.html', {"photo" : photo, "itemname" : itemname, "output": column2D.render(),
                                                "re_name1" : re_name1, "re_photo1" : re_photo1, 
                                                "re_name2" : re_name2, "re_photo2" : re_photo2,
                                                "re_name3" : re_name3, "re_photo3" : re_photo3,
                                                "re_name4" : re_name4, "re_photo4" : re_photo4,
                                                "re_name5" : re_name5, "re_photo5" : re_photo5,
                                                "re_name6" : re_name6, "re_photo6" : re_photo6,
                                                "re_name7" : re_name7, "re_photo7" : re_photo7,
                                                "re_name8" : re_name8, "re_photo8" : re_photo8,
                                                "star" : star,
                                                "positive" : positive,
                                                "negative" : negative,
                                                "re_itemname" : re_itemname}) 


def previous_1(request):
    time.sleep(1)
    itemname = itemname_1
    graph_sql = "select keyword,counts from keyword where itemname = '{}'".format(itemname)
    mycursor.execute(graph_sql)
    graph_source = mycursor.fetchall()[0]
    word = graph_source[0].split()
    counts = graph_source[1].split()

    dataSource = OrderedDict() # 여기부터
    
    chartConfig = OrderedDict()
    chartConfig["caption"] = "상품 키워드 분석 결과"
    chartConfig["subCaption"] = "상품명 : " + itemname
    chartConfig["xAxisName"] = "키워드"
    chartConfig["yAxisName"] = ""
    chartConfig["numberSuffix"] = "개"
    chartConfig["theme"] = "fusion" 

    dataSource["chart"] = chartConfig
    dataSource["data"] = []

    for i in range(len(word)) :
        dataSource["data"].append({"label": word[i], "value": counts[i]})

    column2D = FusionCharts("column2d", "myFirstChart", "650", "650", "myFirstchart-container", "json", dataSource)
    try:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchall()[0][0]
        star = float(mycursor.fetchall()[0][1])


    except:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchone()[0]
        star = float(mycursor.fetchall()[0][1])

    count(itemname)
    category_text = category_df(itemname)
    result_df = recommendation_system(itemname,category_text)

    emotional_sql = 'select positive, negative from keyword where itemname = "{}"'.format(itemname) #######
    mycursor.execute(emotional_sql)
    pos_neg_list = mycursor.fetchone()
    positive, negative = (pos_neg_list[0], pos_neg_list[1])

    global re_name1, re_name2, re_name3, re_name4, re_name5, re_name6, re_name7, re_name8

    re_name1, re_photo1 = refront_1(result_df)
    re_name2, re_photo2 = refront_2(result_df)
    re_name3, re_photo3 = refront_3(result_df)
    re_name4, re_photo4 = refront_4(result_df)
    re_name5, re_photo5 = refront_5(result_df)
    re_name6, re_photo6 = refront_6(result_df)
    re_name7, re_photo7 = refront_7(result_df)
    re_name8, re_photo8 = refront_8(result_df)
    
    re_itemname = clean_text(itemname)

    return render(request, 'post/previous_1.html', {"photo" : photo, "itemname" : itemname, "output": column2D.render(),
                                                "re_name1" : re_name1, "re_photo1" : re_photo1, 
                                                "re_name2" : re_name2, "re_photo2" : re_photo2,
                                                "re_name3" : re_name3, "re_photo3" : re_photo3,
                                                "re_name4" : re_name4, "re_photo4" : re_photo4,
                                                "re_name5" : re_name5, "re_photo5" : re_photo5,
                                                "re_name6" : re_name6, "re_photo6" : re_photo6,
                                                "re_name7" : re_name7, "re_photo7" : re_photo7,
                                                "re_name8" : re_name8, "re_photo8" : re_photo8,
                                                "star" : star,
                                                "positive" : positive,
                                                "negative" : negative,
                                                "re_itemname" : re_itemname}) 

def previous_2(request):
    time.sleep(1)
    itemname = itemname_2
    graph_sql = "select keyword,counts from keyword where itemname = '{}'".format(itemname)
    mycursor.execute(graph_sql)
    graph_source = mycursor.fetchall()[0]
    word = graph_source[0].split()
    counts = graph_source[1].split()

    dataSource = OrderedDict() # 여기부터
    
    chartConfig = OrderedDict()
    chartConfig["caption"] = "상품 키워드 분석 결과"
    chartConfig["subCaption"] = "상품명 : " + itemname
    chartConfig["xAxisName"] = "키워드"
    chartConfig["yAxisName"] = ""
    chartConfig["numberSuffix"] = "개"
    chartConfig["theme"] = "fusion" 

    dataSource["chart"] = chartConfig
    dataSource["data"] = []

    for i in range(len(word)) :
        dataSource["data"].append({"label": word[i], "value": counts[i]})

    column2D = FusionCharts("column2d", "myFirstChart", "650", "650", "myFirstchart-container", "json", dataSource)
    try:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchall()[0][0]
        star = float(mycursor.fetchall()[0][1])


    except:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchone()[0]
        star = float(mycursor.fetchall()[0][1])

    count(itemname)
    category_text = category_df(itemname)
    result_df = recommendation_system(itemname,category_text)

    emotional_sql = 'select positive, negative from keyword where itemname = "{}"'.format(itemname) #######
    mycursor.execute(emotional_sql)
    pos_neg_list = mycursor.fetchone()
    positive, negative = (pos_neg_list[0], pos_neg_list[1])

    global re_name1, re_name2, re_name3, re_name4, re_name5, re_name6, re_name7, re_name8

    re_name1, re_photo1 = refront_1(result_df)
    re_name2, re_photo2 = refront_2(result_df)
    re_name3, re_photo3 = refront_3(result_df)
    re_name4, re_photo4 = refront_4(result_df)
    re_name5, re_photo5 = refront_5(result_df)
    re_name6, re_photo6 = refront_6(result_df)
    re_name7, re_photo7 = refront_7(result_df)
    re_name8, re_photo8 = refront_8(result_df)
    
    re_itemname = clean_text(itemname)

    return render(request, 'post/previous_2.html', {"photo" : photo, "itemname" : itemname, "output": column2D.render(),
                                                "re_name1" : re_name1, "re_photo1" : re_photo1, 
                                                "re_name2" : re_name2, "re_photo2" : re_photo2,
                                                "re_name3" : re_name3, "re_photo3" : re_photo3,
                                                "re_name4" : re_name4, "re_photo4" : re_photo4,
                                                "re_name5" : re_name5, "re_photo5" : re_photo5,
                                                "re_name6" : re_name6, "re_photo6" : re_photo6,
                                                "re_name7" : re_name7, "re_photo7" : re_photo7,
                                                "re_name8" : re_name8, "re_photo8" : re_photo8,
                                                "star" : star,
                                                "positive" : positive,
                                                "negative" : negative,
                                                "re_itemname" : re_itemname}) 

def previous_3(request):
    time.sleep(1)
    itemname = itemname_3
    graph_sql = "select keyword,counts from keyword where itemname = '{}'".format(itemname)
    mycursor.execute(graph_sql)
    graph_source = mycursor.fetchall()[0]
    word = graph_source[0].split()
    counts = graph_source[1].split()

    dataSource = OrderedDict() # 여기부터
    
    chartConfig = OrderedDict()
    chartConfig["caption"] = "상품 키워드 분석 결과"
    chartConfig["subCaption"] = "상품명 : " + itemname
    chartConfig["xAxisName"] = "키워드"
    chartConfig["yAxisName"] = ""
    chartConfig["numberSuffix"] = "개"
    chartConfig["theme"] = "fusion" 

    dataSource["chart"] = chartConfig
    dataSource["data"] = []

    for i in range(len(word)) :
        dataSource["data"].append({"label": word[i], "value": counts[i]})

    column2D = FusionCharts("column2d", "myFirstChart", "650", "650", "myFirstchart-container", "json", dataSource)
    try:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchall()[0][0]
        star = float(mycursor.fetchall()[0][1])


    except:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchone()[0]
        star = float(mycursor.fetchall()[0][1])

    count(itemname)
    category_text = category_df(itemname)
    result_df = recommendation_system(itemname,category_text)

    emotional_sql = 'select positive, negative from keyword where itemname = "{}"'.format(itemname) #######
    mycursor.execute(emotional_sql)
    pos_neg_list = mycursor.fetchone()
    positive, negative = (pos_neg_list[0], pos_neg_list[1])

    global re_name1, re_name2, re_name3, re_name4, re_name5, re_name6, re_name7, re_name8

    re_name1, re_photo1 = refront_1(result_df)
    re_name2, re_photo2 = refront_2(result_df)
    re_name3, re_photo3 = refront_3(result_df)
    re_name4, re_photo4 = refront_4(result_df)
    re_name5, re_photo5 = refront_5(result_df)
    re_name6, re_photo6 = refront_6(result_df)
    re_name7, re_photo7 = refront_7(result_df)
    re_name8, re_photo8 = refront_8(result_df)
    
    re_itemname = clean_text(itemname)

    return render(request, 'post/previous_3.html', {"photo" : photo, "itemname" : itemname, "output": column2D.render(),
                                                "re_name1" : re_name1, "re_photo1" : re_photo1, 
                                                "re_name2" : re_name2, "re_photo2" : re_photo2,
                                                "re_name3" : re_name3, "re_photo3" : re_photo3,
                                                "re_name4" : re_name4, "re_photo4" : re_photo4,
                                                "re_name5" : re_name5, "re_photo5" : re_photo5,
                                                "re_name6" : re_name6, "re_photo6" : re_photo6,
                                                "re_name7" : re_name7, "re_photo7" : re_photo7,
                                                "re_name8" : re_name8, "re_photo8" : re_photo8,
                                                "star" : star,
                                                "positive" : positive,
                                                "negative" : negative,
                                                "re_itemname" : re_itemname}) 
def previous_4(request):
    time.sleep(1)
    itemname = itemname_4
    graph_sql = "select keyword,counts from keyword where itemname = '{}'".format(itemname)
    mycursor.execute(graph_sql)
    graph_source = mycursor.fetchall()[0]
    word = graph_source[0].split()
    counts = graph_source[1].split()

    dataSource = OrderedDict() # 여기부터
    
    chartConfig = OrderedDict()
    chartConfig["caption"] = "상품 키워드 분석 결과"
    chartConfig["subCaption"] = "상품명 : " + itemname
    chartConfig["xAxisName"] = "키워드"
    chartConfig["yAxisName"] = ""
    chartConfig["numberSuffix"] = "개"
    chartConfig["theme"] = "fusion" 

    dataSource["chart"] = chartConfig
    dataSource["data"] = []

    for i in range(len(word)) :
        dataSource["data"].append({"label": word[i], "value": counts[i]})

    column2D = FusionCharts("column2d", "myFirstChart", "650", "650", "myFirstchart-container", "json", dataSource)
    try:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchall()[0][0]
        star = float(mycursor.fetchall()[0][1])


    except:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchone()[0]
        star = float(mycursor.fetchall()[0][1])

    count(itemname)
    category_text = category_df(itemname)
    result_df = recommendation_system(itemname,category_text)

    emotional_sql = 'select positive, negative from keyword where itemname = "{}"'.format(itemname) #######
    mycursor.execute(emotional_sql)
    pos_neg_list = mycursor.fetchone()
    positive, negative = (pos_neg_list[0], pos_neg_list[1])

    global re_name1, re_name2, re_name3, re_name4, re_name5, re_name6, re_name7, re_name8

    re_name1, re_photo1 = refront_1(result_df)
    re_name2, re_photo2 = refront_2(result_df)
    re_name3, re_photo3 = refront_3(result_df)
    re_name4, re_photo4 = refront_4(result_df)
    re_name5, re_photo5 = refront_5(result_df)
    re_name6, re_photo6 = refront_6(result_df)
    re_name7, re_photo7 = refront_7(result_df)
    re_name8, re_photo8 = refront_8(result_df)
    
    re_itemname = clean_text(itemname)

    return render(request, 'post/previous_4.html', {"photo" : photo, "itemname" : itemname, "output": column2D.render(),
                                                "re_name1" : re_name1, "re_photo1" : re_photo1, 
                                                "re_name2" : re_name2, "re_photo2" : re_photo2,
                                                "re_name3" : re_name3, "re_photo3" : re_photo3,
                                                "re_name4" : re_name4, "re_photo4" : re_photo4,
                                                "re_name5" : re_name5, "re_photo5" : re_photo5,
                                                "re_name6" : re_name6, "re_photo6" : re_photo6,
                                                "re_name7" : re_name7, "re_photo7" : re_photo7,
                                                "re_name8" : re_name8, "re_photo8" : re_photo8,
                                                "star" : star,
                                                "positive" : positive,
                                                "negative" : negative,
                                                "re_itemname" : re_itemname}) 

def repage_1(request):
    global itemname, re_page_name1  # 이 부분 추가
    
    re_page_name1 = re_name1 
    time.sleep(1)
    itemname = re_page_name1  # 이 부분까지
    graph_sql = "select keyword,counts from keyword where itemname = '{}'".format(itemname)
    mycursor.execute(graph_sql)
    graph_source = mycursor.fetchall()[0]
    word = graph_source[0].split()
    counts = graph_source[1].split()

    dataSource = OrderedDict() # 여기부터
    
    chartConfig = OrderedDict()
    chartConfig["caption"] = "상품 키워드 분석 결과"
    chartConfig["subCaption"] = "상품명 : " + itemname
    chartConfig["xAxisName"] = "키워드"
    chartConfig["yAxisName"] = ""
    chartConfig["numberSuffix"] = "개"
    chartConfig["theme"] = "fusion" 

    dataSource["chart"] = chartConfig
    dataSource["data"] = []

    for i in range(len(word)) :
        dataSource["data"].append({"label": word[i], "value": counts[i]})

    column2D = FusionCharts("column2d", "myFirstChart", "650", "650", "myFirstchart-container", "json", dataSource)
    try:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchall()[0][0]
        star = float(mycursor.fetchall()[0][1])

    except:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchone()[0]
        star = float(mycursor.fetchall()[0][1])

    count(itemname)
    category_text = category_df(itemname)
    result_df = recommendation_system(itemname,category_text)

    emotional_sql = 'select positive, negative from keyword where itemname = "{}"'.format(itemname) #######
    mycursor.execute(emotional_sql)
    pos_neg_list = mycursor.fetchone()
    positive, negative = (pos_neg_list[0], pos_neg_list[1])

    global rere_name1, re_name2, re_name3, re_name4, re_name5, re_name6, re_name7, re_name8  # 이 부분 추가 및 변경

    rere_name1, rere_photo1 = refront_1(result_df)  # 이 부분 추가 및 변경
    re_name2, re_photo2 = refront_2(result_df)
    re_name3, re_photo3 = refront_3(result_df)
    re_name4, re_photo4 = refront_4(result_df)
    re_name5, re_photo5 = refront_5(result_df)
    re_name6, re_photo6 = refront_6(result_df)
    re_name7, re_photo7 = refront_7(result_df)
    re_name8, re_photo8 = refront_8(result_df)
            
    re_itemname = clean_text(itemname)
    return render(request, 'post/repage_1.html', {"photo" : photo, "itemname" : itemname, "output": column2D.render(),
                                                "re_name1" : rere_name1, "re_photo1" : rere_photo1,  # 이 부분 추가 및 변경
                                                "re_name2" : re_name2, "re_photo2" : re_photo2,
                                                "re_name3" : re_name3, "re_photo3" : re_photo3,
                                                "re_name4" : re_name4, "re_photo4" : re_photo4,
                                                "re_name5" : re_name5, "re_photo5" : re_photo5,
                                                "re_name6" : re_name6, "re_photo6" : re_photo6,
                                                "re_name7" : re_name7, "re_photo7" : re_photo7,
                                                "re_name8" : re_name8, "re_photo8" : re_photo8,
                                                "star" : star,
                                                "positive" : positive,
                                                "negative" : negative,
                                                "re_itemname" : re_itemname}) 

def repage_2(request):
    global itemname, re_page_name2 # 이 부분 추가
    re_page_name2 = re_name2
    time.sleep(1)
    itemname = re_page_name2 # 이 부분까지
    graph_sql = "select keyword,counts from keyword where itemname = '{}'".format(itemname)
    mycursor.execute(graph_sql)
    graph_source = mycursor.fetchall()[0]
    word = graph_source[0].split()
    counts = graph_source[1].split()

    dataSource = OrderedDict() # 여기부터
    
    chartConfig = OrderedDict()
    chartConfig["caption"] = "상품 키워드 분석 결과"
    chartConfig["subCaption"] = "상품명 : " + itemname
    chartConfig["xAxisName"] = "키워드"
    chartConfig["yAxisName"] = ""
    chartConfig["numberSuffix"] = "개"
    chartConfig["theme"] = "fusion" 

    dataSource["chart"] = chartConfig
    dataSource["data"] = []

    for i in range(len(word)) :
        dataSource["data"].append({"label": word[i], "value": counts[i]})

    column2D = FusionCharts("column2d", "myFirstChart", "650", "650", "myFirstchart-container", "json", dataSource)
    try:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchall()[0][0]
        star = float(mycursor.fetchall()[0][1])

    except:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchone()[0]
        star = float(mycursor.fetchall()[0][1])

    count(itemname)
    category_text = category_df(itemname)
    result_df = recommendation_system(itemname,category_text)

    emotional_sql = 'select positive, negative from keyword where itemname = "{}"'.format(itemname) #######
    mycursor.execute(emotional_sql)
    pos_neg_list = mycursor.fetchone()
    positive, negative = (pos_neg_list[0], pos_neg_list[1])

    global re_name1, rere_name2, re_name3, re_name4, re_name5, re_name6, re_name7, re_name8  # 이 부분 추가 및 변경

    re_name1, re_photo1 = refront_1(result_df)
    rere_name2, rere_photo2 = refront_2(result_df)  # 이 부분 추가 및 변경
    re_name3, re_photo3 = refront_3(result_df)
    re_name4, re_photo4 = refront_4(result_df)
    re_name5, re_photo5 = refront_5(result_df)
    re_name6, re_photo6 = refront_6(result_df)
    re_name7, re_photo7 = refront_7(result_df)
    re_name8, re_photo8 = refront_8(result_df)
            
    re_itemname = clean_text(itemname)
    return render(request, 'post/repage_2.html', {"photo" : photo, "itemname" : itemname, "output": column2D.render(),
                                                "re_name1" : re_name1, "re_photo1" : re_photo1, 
                                                "re_name2" : rere_name2, "re_photo2" : rere_photo2,  # 이 부분 추가 및 변경
                                                "re_name3" : re_name3, "re_photo3" : re_photo3,
                                                "re_name4" : re_name4, "re_photo4" : re_photo4,
                                                "re_name5" : re_name5, "re_photo5" : re_photo5,
                                                "re_name6" : re_name6, "re_photo6" : re_photo6,
                                                "re_name7" : re_name7, "re_photo7" : re_photo7,
                                                "re_name8" : re_name8, "re_photo8" : re_photo8,
                                                "star" : star,
                                                "positive" : positive,
                                                "negative" : negative,
                                                "re_itemname" : re_itemname}) 

def repage_3(request):
    global itemname, re_page_name3  # 이 부분 추가
    re_page_name3 = re_name3
    time.sleep(1)
    itemname = re_page_name3  # 이 부분까지
    graph_sql = "select keyword,counts from keyword where itemname = '{}'".format(itemname)
    mycursor.execute(graph_sql)
    graph_source = mycursor.fetchall()[0]
    word = graph_source[0].split()
    counts = graph_source[1].split()

    dataSource = OrderedDict() # 여기부터
    
    chartConfig = OrderedDict()
    chartConfig["caption"] = "상품 키워드 분석 결과"
    chartConfig["subCaption"] = "상품명 : " + itemname
    chartConfig["xAxisName"] = "키워드"
    chartConfig["yAxisName"] = ""
    chartConfig["numberSuffix"] = "개"
    chartConfig["theme"] = "fusion" 

    dataSource["chart"] = chartConfig
    dataSource["data"] = []

    for i in range(len(word)) :
        dataSource["data"].append({"label": word[i], "value": counts[i]})

    column2D = FusionCharts("column2d", "myFirstChart", "650", "650", "myFirstchart-container", "json", dataSource)
    try:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchall()[0][0]
        star = float(mycursor.fetchall()[0][1])

    except:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchone()[0]
        star = float(mycursor.fetchall()[0][1])

    count(itemname)
    category_text = category_df(itemname)
    result_df = recommendation_system(itemname,category_text)

    emotional_sql = 'select positive, negative from keyword where itemname = "{}"'.format(itemname) #######
    mycursor.execute(emotional_sql)
    pos_neg_list = mycursor.fetchone()
    positive, negative = (pos_neg_list[0], pos_neg_list[1])

    global re_name1, re_name2, rere_name3, re_name4, re_name5, re_name6, re_name7, re_name8  # 이 부분 추가 및 변경

    re_name1, re_photo1 = refront_1(result_df)
    re_name2, re_photo2 = refront_2(result_df)
    rere_name3, rere_photo3 = refront_3(result_df)  # 이 부분 추가 및 변경
    re_name4, re_photo4 = refront_4(result_df)
    re_name5, re_photo5 = refront_5(result_df)
    re_name6, re_photo6 = refront_6(result_df)
    re_name7, re_photo7 = refront_7(result_df)
    re_name8, re_photo8 = refront_8(result_df)
            
    re_itemname = clean_text(itemname)

    return render(request, 'post/repage_3.html', {"photo" : photo, "itemname" : itemname, "output": column2D.render(),
                                                "re_name1" : re_name1, "re_photo1" : re_photo1, 
                                                "re_name2" : re_name2, "re_photo2" : re_photo2,
                                                "re_name3" : rere_name3, "re_photo3" : rere_photo3,  # 이 부분 추가 및 변경
                                                "re_name4" : re_name4, "re_photo4" : re_photo4,
                                                "re_name5" : re_name5, "re_photo5" : re_photo5,
                                                "re_name6" : re_name6, "re_photo6" : re_photo6,
                                                "re_name7" : re_name7, "re_photo7" : re_photo7,
                                                "re_name8" : re_name8, "re_photo8" : re_photo8,
                                                "star" : star,
                                                "positive" : positive,
                                                "negative" : negative,
                                                "re_itemname" : re_itemname}) 

def repage_4(request):
    global itemname, re_page_name4  # 이 부분 추가
    re_page_name4 = re_name4
    time.sleep(1)
    itemname = re_page_name4  # 이 부분까지
    graph_sql = "select keyword,counts from keyword where itemname = '{}'".format(itemname)
    mycursor.execute(graph_sql)
    graph_source = mycursor.fetchall()[0]
    word = graph_source[0].split()
    counts = graph_source[1].split()

    dataSource = OrderedDict() # 여기부터
    
    chartConfig = OrderedDict()
    chartConfig["caption"] = "상품 키워드 분석 결과"
    chartConfig["subCaption"] = "상품명 : " + itemname
    chartConfig["xAxisName"] = "키워드"
    chartConfig["yAxisName"] = ""
    chartConfig["numberSuffix"] = "개"
    chartConfig["theme"] = "fusion" 

    dataSource["chart"] = chartConfig
    dataSource["data"] = []

    for i in range(len(word)) :
        dataSource["data"].append({"label": word[i], "value": counts[i]})

    column2D = FusionCharts("column2d", "myFirstChart", "650", "650", "myFirstchart-container", "json", dataSource)
    try:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchall()[0][0]
        star = float(mycursor.fetchall()[0][1])

    except:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchone()[0]
        star = float(mycursor.fetchall()[0][1])

    count(itemname)
    category_text = category_df(itemname)
    result_df = recommendation_system(itemname,category_text)

    emotional_sql = 'select positive, negative from keyword where itemname = "{}"'.format(itemname) #######
    mycursor.execute(emotional_sql)
    pos_neg_list = mycursor.fetchone()
    positive, negative = (pos_neg_list[0], pos_neg_list[1])

    global re_name1, re_name2, re_name3, rere_name4, re_name5, re_name6, re_name7, re_name8  # 이 부분 추가 및 변경

    re_name1, re_photo1 = refront_1(result_df)
    re_name2, re_photo2 = refront_2(result_df)
    re_name3, re_photo3 = refront_3(result_df)
    rere_name4, rere_photo4 = refront_4(result_df)  # 이 부분 추가 및 변경
    re_name5, re_photo5 = refront_5(result_df)
    re_name6, re_photo6 = refront_6(result_df)
    re_name7, re_photo7 = refront_7(result_df)
    re_name8, re_photo8 = refront_8(result_df)
            
    re_itemname = clean_text(itemname)

    return render(request, 'post/repage_4.html', {"photo" : photo, "itemname" : itemname, "output": column2D.render(),
                                                "re_name1" : re_name1, "re_photo1" : re_photo1, 
                                                "re_name2" : re_name2, "re_photo2" : re_photo2,
                                                "re_name3" : re_name3, "re_photo3" : re_photo3,
                                                "re_name4" : rere_name4, "re_photo4" : rere_photo4,  # 이 부분 추가 및 변경
                                                "re_name5" : re_name5, "re_photo5" : re_photo5,
                                                "re_name6" : re_name6, "re_photo6" : re_photo6,
                                                "re_name7" : re_name7, "re_photo7" : re_photo7,
                                                "re_name8" : re_name8, "re_photo8" : re_photo8,
                                                "star" : star,
                                                "positive" : positive,
                                                "negative" : negative,
                                                "re_itemname" : re_itemname}) 

def repage_5(request):
    global itemname, re_page_name5  # 이 부분 추가
    re_page_name5 = re_name5
    time.sleep(1)
    itemname = re_page_name5  # 이 부분까지
    graph_sql = "select keyword,counts from keyword where itemname = '{}'".format(itemname)
    mycursor.execute(graph_sql)
    graph_source = mycursor.fetchall()[0]
    word = graph_source[0].split()
    counts = graph_source[1].split()

    dataSource = OrderedDict() # 여기부터
    
    chartConfig = OrderedDict()
    chartConfig["caption"] = "상품 키워드 분석 결과"
    chartConfig["subCaption"] = "상품명 : " + itemname
    chartConfig["xAxisName"] = "키워드"
    chartConfig["yAxisName"] = ""
    chartConfig["numberSuffix"] = "개"
    chartConfig["theme"] = "fusion" 

    dataSource["chart"] = chartConfig
    dataSource["data"] = []

    for i in range(len(word)) :
        dataSource["data"].append({"label": word[i], "value": counts[i]})

    column2D = FusionCharts("column2d", "myFirstChart", "650", "650", "myFirstchart-container", "json", dataSource)
    try:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchall()[0][0]
        star = float(mycursor.fetchall()[0][1])

    except:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchone()[0]
        star = float(mycursor.fetchall()[0][1])

    count(itemname)
    category_text = category_df(itemname)
    result_df = recommendation_system(itemname,category_text)

    emotional_sql = 'select positive, negative from keyword where itemname = "{}"'.format(itemname) #######
    mycursor.execute(emotional_sql)
    pos_neg_list = mycursor.fetchone()
    positive, negative = (pos_neg_list[0], pos_neg_list[1])

    global re_name1, re_name2, re_name3, re_name4, rere_name5, re_name6, re_name7, re_name8  # 이 부분 추가 및 변경

    re_name1, re_photo1 = refront_1(result_df)
    re_name2, re_photo2 = refront_2(result_df)
    re_name3, re_photo3 = refront_3(result_df)
    re_name4, re_photo4 = refront_4(result_df)
    rere_name5, rere_photo5 = refront_5(result_df)  # 이 부분 추가 및 변경
    re_name6, re_photo6 = refront_6(result_df)
    re_name7, re_photo7 = refront_7(result_df)
    re_name8, re_photo8 = refront_8(result_df)
            
    re_itemname = clean_text(itemname)

    return render(request, 'post/repage_5.html', {"photo" : photo, "itemname" : itemname, "output": column2D.render(),
                                                "re_name1" : re_name1, "re_photo1" : re_photo1, 
                                                "re_name2" : re_name2, "re_photo2" : re_photo2,
                                                "re_name3" : re_name3, "re_photo3" : re_photo3,
                                                "re_name4" : re_name4, "re_photo4" : re_photo4,
                                                "re_name5" : rere_name5, "re_photo5" : rere_photo5,  # 이 부분 추가 및 변경
                                                "re_name6" : re_name6, "re_photo6" : re_photo6,
                                                "re_name7" : re_name7, "re_photo7" : re_photo7,
                                                "re_name8" : re_name8, "re_photo8" : re_photo8,
                                                "star" : star,
                                                "positive" : positive,
                                                "negative" : negative,
                                                "re_itemname" : re_itemname}) 

def repage_6(request):
    global itemname, re_page_name6  # 이 부분 추가
    re_page_name6 = re_name6
    time.sleep(1)
    itemname = re_page_name6  # 이 부분까지
    graph_sql = "select keyword,counts from keyword where itemname = '{}'".format(itemname)
    mycursor.execute(graph_sql)
    graph_source = mycursor.fetchall()[0]
    word = graph_source[0].split()
    counts = graph_source[1].split()

    dataSource = OrderedDict() # 여기부터
    
    chartConfig = OrderedDict()
    chartConfig["caption"] = "상품 키워드 분석 결과"
    chartConfig["subCaption"] = "상품명 : " + itemname
    chartConfig["xAxisName"] = "키워드"
    chartConfig["yAxisName"] = ""
    chartConfig["numberSuffix"] = "개"
    chartConfig["theme"] = "fusion" 

    dataSource["chart"] = chartConfig
    dataSource["data"] = []

    for i in range(len(word)) :
        dataSource["data"].append({"label": word[i], "value": counts[i]})

    column2D = FusionCharts("column2d", "myFirstChart", "650", "650", "myFirstchart-container", "json", dataSource)
    try:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchall()[0][0]
        star = float(mycursor.fetchall()[0][1])

    except:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchone()[0]
        star = float(mycursor.fetchall()[0][1])

    count(itemname)
    category_text = category_df(itemname)
    result_df = recommendation_system(itemname,category_text)

    emotional_sql = 'select positive, negative from keyword where itemname = "{}"'.format(itemname) #######
    mycursor.execute(emotional_sql)
    pos_neg_list = mycursor.fetchone()
    positive, negative = (pos_neg_list[0], pos_neg_list[1])

    global re_name1, re_name2, re_name3, re_name4, re_name5, rere_name6, re_name7, re_name8  # 이 부분 추가 및 변경

    re_name1, re_photo1 = refront_1(result_df)
    re_name2, re_photo2 = refront_2(result_df)
    re_name3, re_photo3 = refront_3(result_df)
    re_name4, re_photo4 = refront_4(result_df)
    re_name5, re_photo5 = refront_5(result_df)
    rere_name6, rere_photo6 = refront_6(result_df)  # 이 부분 추가 및 변경
    re_name7, re_photo7 = refront_7(result_df)
    re_name8, re_photo8 = refront_8(result_df)

    re_itemname = clean_text(itemname)

    return render(request, 'post/repage_6.html', {"photo" : photo, "itemname" : itemname, "output": column2D.render(),
                                                "re_name1" : re_name1, "re_photo1" : re_photo1, 
                                                "re_name2" : re_name2, "re_photo2" : re_photo2,
                                                "re_name3" : re_name3, "re_photo3" : re_photo3,
                                                "re_name4" : re_name4, "re_photo4" : re_photo4,
                                                "re_name5" : re_name5, "re_photo5" : re_photo5,
                                                "re_name6" : rere_name6, "re_photo6" : rere_photo6,  # 이 부분 추가 및 변경
                                                "re_name7" : re_name7, "re_photo7" : re_photo7,
                                                "re_name8" : re_name8, "re_photo8" : re_photo8,
                                                "star" : star,
                                                "positive" : positive,
                                                "negative" : negative,
                                                "re_itemname" : re_itemname}) 

def repage_7(request):
    global itemname, re_page_name7  # 이 부분 추가
    re_page_name7 = re_name7
    time.sleep(1)
    itemname = re_page_name7  # 이 부분까지
    graph_sql = "select keyword,counts from keyword where itemname = '{}'".format(itemname)
    mycursor.execute(graph_sql)
    graph_source = mycursor.fetchall()[0]
    word = graph_source[0].split()
    counts = graph_source[1].split()

    dataSource = OrderedDict() # 여기부터
    
    chartConfig = OrderedDict()
    chartConfig["caption"] = "상품 키워드 분석 결과"
    chartConfig["subCaption"] = "상품명 : " + itemname
    chartConfig["xAxisName"] = "키워드"
    chartConfig["yAxisName"] = ""
    chartConfig["numberSuffix"] = "개"
    chartConfig["theme"] = "fusion" 

    dataSource["chart"] = chartConfig
    dataSource["data"] = []

    for i in range(len(word)) :
        dataSource["data"].append({"label": word[i], "value": counts[i]})

    column2D = FusionCharts("column2d", "myFirstChart", "650", "650", "myFirstchart-container", "json", dataSource)
    try:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchall()[0][0]
        star = float(mycursor.fetchall()[0][1])

    except:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchone()[0]
        star = float(mycursor.fetchall()[0][1])

    count(itemname)
    category_text = category_df(itemname)
    result_df = recommendation_system(itemname,category_text)

    emotional_sql = 'select positive, negative from keyword where itemname = "{}"'.format(itemname) #######
    mycursor.execute(emotional_sql)
    pos_neg_list = mycursor.fetchone()
    positive, negative = (pos_neg_list[0], pos_neg_list[1])

    global re_name1, re_name2, re_name3, re_name4, re_name5, re_name6, rere_name7, re_name8  # 이 부분 추가 및 변경

    re_name1, re_photo1 = refront_1(result_df)
    re_name2, re_photo2 = refront_2(result_df)
    re_name3, re_photo3 = refront_3(result_df)
    re_name4, re_photo4 = refront_4(result_df)
    re_name5, re_photo5 = refront_5(result_df)
    re_name6, re_photo6 = refront_6(result_df)
    rere_name7, rere_photo7 = refront_7(result_df)  # 이 부분 추가 및 변경
    re_name8, re_photo8 = refront_8(result_df)
            
    re_itemname = clean_text(itemname)

    return render(request, 'post/repage_7.html', {"photo" : photo, "itemname" : itemname, "output": column2D.render(),
                                                "re_name1" : re_name1, "re_photo1" : re_photo1, 
                                                "re_name2" : re_name2, "re_photo2" : re_photo2,
                                                "re_name3" : re_name3, "re_photo3" : re_photo3,
                                                "re_name4" : re_name4, "re_photo4" : re_photo4,
                                                "re_name5" : re_name5, "re_photo5" : re_photo5,
                                                "re_name6" : re_name6, "re_photo6" : re_photo6,
                                                "re_name7" : rere_name7, "re_photo7" : rere_photo7,  # 이 부분 추가 및 변경
                                                "re_name8" : re_name8, "re_photo8" : re_photo8,
                                                "star" : star,
                                                "positive" : positive,
                                                "negative" : negative,
                                                "re_itemname": re_itemname}) 

def repage_8(request):
    global itemname, re_page_name8  # 이 부분 추가
    re_page_name8 = re_name8
    time.sleep(1)
    itemname = re_page_name8  # 이 부분까지
    graph_sql = "select keyword,counts from keyword where itemname = '{}'".format(itemname)
    mycursor.execute(graph_sql)
    graph_source = mycursor.fetchall()[0]
    word = graph_source[0].split()
    counts = graph_source[1].split()

    dataSource = OrderedDict() # 여기부터
    
    chartConfig = OrderedDict()
    chartConfig["caption"] = "상품 키워드 분석 결과"
    chartConfig["subCaption"] = "상품명 : " + itemname
    chartConfig["xAxisName"] = "키워드"
    chartConfig["yAxisName"] = ""
    chartConfig["numberSuffix"] = "개"
    chartConfig["theme"] = "fusion" 

    dataSource["chart"] = chartConfig
    dataSource["data"] = []

    for i in range(len(word)) :
        dataSource["data"].append({"label": word[i], "value": counts[i]})

    column2D = FusionCharts("column2d", "myFirstChart", "650", "650", "myFirstchart-container", "json", dataSource)
    try:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchall()[0][0]
        star = float(mycursor.fetchall()[0][1])

    except:

        photo_sql = 'select img_url,star from craw where itemname = "{}" '.format(itemname)
        mycursor.execute(photo_sql)
        photo = mycursor.fetchone()[0]
        star = float(mycursor.fetchall()[0][1])

    count(itemname)
    category_text = category_df(itemname)
    result_df = recommendation_system(itemname,category_text)

    emotional_sql = 'select positive, negative from keyword where itemname = "{}"'.format(itemname) #######
    mycursor.execute(emotional_sql)
    pos_neg_list = mycursor.fetchone()
    positive, negative = (pos_neg_list[0], pos_neg_list[1])

    global re_name1, re_name2, re_name3, re_name4, re_name5, re_name6, re_name7, rere_name8  # 이 부분 추가 및 변경

    re_name1, re_photo1 = refront_1(result_df)
    re_name2, re_photo2 = refront_2(result_df)
    re_name3, re_photo3 = refront_3(result_df)
    re_name4, re_photo4 = refront_4(result_df)
    re_name5, re_photo5 = refront_5(result_df)
    re_name6, re_photo6 = refront_6(result_df)
    re_name7, re_photo7 = refront_7(result_df)
    rere_name8, rere_photo8 = refront_8(result_df)  # 이 부분 추가 및 변경
            
    re_itemname = clean_text(itemname)

    return render(request, 'post/repage_8.html', {"photo" : photo, "itemname" : itemname, "output": column2D.render(),
                                                "re_name1" : re_name1, "re_photo1" : re_photo1, 
                                                "re_name2" : re_name2, "re_photo2" : re_photo2,
                                                "re_name3" : re_name3, "re_photo3" : re_photo3,
                                                "re_name4" : re_name4, "re_photo4" : re_photo4,
                                                "re_name5" : re_name5, "re_photo5" : re_photo5,
                                                "re_name6" : re_name6, "re_photo6" : re_photo6,
                                                "re_name7" : re_name7, "re_photo7" : re_photo7,
                                                "re_name8" : rere_name8, "re_photo8" : rere_photo8,
                                                "star" : star,
                                                "positive" : positive,
                                                "negative" : negative,
                                                "re_itemname": re_itemname})