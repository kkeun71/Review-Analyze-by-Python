import pymysql
from konlpy.tag import *
import pandas as pd
from .clean_text import clean_text
import re
from .logistic import logistic
from pymysql.constants import CLIENT

# 리뷰 내에서 키워드를 추출하는 함수
def keyword(itemname,tfv):
    conn = pymysql.connect(host='localhost', # DB 연결
                        user='root',
                        password='1234',
                        db='abcds',
                        charset='utf8',
                        client_flag = CLIENT.MULTI_STATEMENTS,
                        )

    sql = "select * from craw where itemname = %s"
    cursor = conn.cursor()

    cursor.execute(sql, itemname)
    res = cursor.fetchall()

    # 추출되는 키워드 중 의미를 알 수 없는 키워드는 추출하지 않도록 검사하기 위해 텍스트 데이터 불러옴
    stopwords = open("template/stop.txt", "r", encoding="utf-8") 
    stop_list = []

    # 배열에 텍스트 데이터에서 불러온 문자열 추가 (키워드 추출에 대한 필터를 만드는 과정)
    for word in stopwords:
        newword = re.sub("\n", "", word)
        stop_list.append(newword)

    text_list = []
    
    # 상품 정보
    itemname = res[0][1]
    url = res[0][2]
    img_url = res[0][4]
    star = res[0][5]
    category = res[0][6]

    # 해당 상품의 리뷰에 대한 텍스트 전처리 후 배열에 저장
    for i in range(len(res)):
        text_data = str(res[i][3])
        clean_data = clean_text(text_data)
        text_list.append(clean_data)

    # 형태소 분석기 생성
    okt = Okt()

    # 형태소 분석 및 단어 토큰화
    okt_data = okt.nouns(str(text_list))
 
    # 전처리된 단어 중 단어 길이가 0인 경우 제거
    okt_word = [n for n in okt_data if len(n) > 1]

    # stop_list에 포함되지 않는 키워드만 new_word배열에 추가
    new_word = []
    for word in okt_word:
        if word not in stop_list:
            new_word.append(word)

    # 추출된 키워드를 DataFrame 형태로 변환 
    word_df = pd.DataFrame(new_word)

    # 모든 키워드의 개수 측정 (ex: 사람 : 57개, 동물 : 32개)
    word_df = word_df.value_counts()

    # 측정된 키워드의 종류가 몇가지인지 저장 (ex: 사람, 동물, 인형, 식물 -> 4개)
    row_count = len(word_df)
    
    # 키워드의 종류가 10가지 이상인 경우 DataFrame의 길이를 10개로 제한하고 아닐 경우에는 그대로 사용
    if row_count >= 10:
        word_df = word_df.head(10)
    else:
        word_df = word_df.head(row_count)

    # 시각화 자료에 사용하기 위해 DataFrame을 수정하고 데이터 전처리 수행
    word_df = pd.DataFrame(word_df, columns=["count"])
    word_df = word_df.reset_index()
    word_df.columns = ["word", "count"]
    word_df["word"].str.strip()
    word_df["count"] = word_df["count"].apply(str)

    #DB에 입력하기 위한 키워드 리스트 생성
    word_list = []
    for word in word_df["word"]:
        word_list.append(word)

    #DB에 입력하기 위한 각 키워드의 개수 리스트 생성
    count_list = []
    for count in word_df["count"]:
        count_list.append(count)
 
    # 키워드와 키워드의 개수를 공백 단위로 join
    word_result = ' '.join(s for s in word_list)

    count_result = ' '.join(s for s in count_list)

    # 감성분석 결과 변수에 저장
    positive, negative = logistic(itemname,tfv)
    
    # 키워드 추출 결과를 Keyword 테이블에 Insert
    result_list = []
    result_list.append(itemname)
    result_list.append(url)
    result_list.append(word_result)
    result_list.append(img_url)
    result_list.append(star)
    result_list.append(count_result)
    result_list.append(category)
    result_list.append(positive)
    result_list.append(negative)

    result_list = tuple(result_list)
    
    insert_sql = "insert into keyword (itemname, url, keyword, img_url, star, counts, category,positive, negative) values (%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    cursor.execute(insert_sql,result_list)
    conn.commit()
    conn.close()