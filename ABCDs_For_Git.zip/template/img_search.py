import pymysql

# 이미지 정보를 통해 제품의 모든 정보 추출하는 함수
def img_se(img_url):
    conn = pymysql.connect(host='localhost',
                        user='root',
                        password='1234',
                        db='abcds',
                        charset='utf8')

    sql = "select * from keyword where img_url = %s"
    cursor = conn.cursor()

    cursor.execute(sql, img_url)
    res = cursor.fetchall()

    itemname = res[0][1]
    url = res[0][2]
    keyword = res[0][3]
    img_url = res[0][4]
    star = res[0][5]
    count = res[0][6]

    result_list = []

    result_list.append(itemname)
    result_list.append(url)
    result_list.append(keyword)
    result_list.append(img_url)
    result_list.append(itemname)
    result_list.append(star)
    result_list.append(count)
    
    
    return result_list

