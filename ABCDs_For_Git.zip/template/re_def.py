import pandas as pd
import pymysql

# 카테고리 별 추천을 해주기 위해 검색된 상품의 카테고리 추출하는 함수
def category_df(itemname):
    global category_result
    conn = pymysql.connect(host='localhost',
                        user='root',
                        password='1234',
                        db='abcds',
                        charset='utf8mb4')
                        
    cursor = conn.cursor()
    sql = "SELECT category FROM keyword where itemname = %s"

    cursor.execute(sql,itemname)
    res = cursor.fetchall()
    conn.close()
    
    category_result = res[0][0]
    return category_result

def recommendation_system(item_name, category):
    conn = pymysql.connect(host='localhost',
                        user='root',
                        port=3306,
                        password='1234',
                        db='abcds',
                        charset='utf8mb4',
                        cursorclass = pymysql.cursors.DictCursor)

    re_itemname = item_name

    cursor = conn.cursor()
    sql = "SELECT itemname,keyword,img_url,star,category FROM keyword"

    # keyword 테이블 내의 데이터를 가져옴
    cursor.execute(sql)
    res = cursor.fetchall()
    conn.close()

    # 가져온 데이터를 DataFrame 형태로 변환 후 중복 제거 및 검색된 상품과 같은 카테고리만 남도록 전처리
    result_df = pd.DataFrame(res)
    re_df = result_df.copy().drop_duplicates()
    re_df = re_df[re_df["category"] == category]
    re_df = re_df.reset_index(drop=True)

    # 카테고리 컬럼만 복사
    category_df = re_df["category"].copy()
    
    # 카테고리 제외한 나머지 컬럼에 해당하는 DF 복사
    join_df = re_df[["itemname", "keyword", "img_url", "star"]].copy()
    keyword = join_df["keyword"]
    keyword = keyword + " " + category_df

    join_df["keyword"] = keyword

    # 문자열을 숫자로 바꾸어 벡터화 시켜야 함. sklearn의 CountVectorizer 사용
    from sklearn.feature_extraction.text import CountVectorizer
    # 객체로 만들고
    count_vector = CountVectorizer(ngram_range=(1,3))

    c_vector_genres = count_vector.fit_transform(join_df['keyword'])

    from sklearn.metrics.pairwise import cosine_similarity

    # 코사인 유사도를 구한 벡터를 미리 저장
    geren_c_sim = cosine_similarity(c_vector_genres, c_vector_genres).argsort()[:, ::-1]
    print(geren_c_sim.shape)

    def get_recommend_item_list(df, item_title, top=30):
        # 특정 아이템와 비슷한 아이템를 추천해야 하기 때문에 '특정 아이템' 정보를 뽑아낸다.
        target_item_index = df[df['itemname'] == item_title].index.values

        # 코사인 유사도 중 비슷한 코사인 유사도를 가진 정보를 뽑아낸다
        sim_index = geren_c_sim[target_item_index, :top].reshape(-1)

        # 본인을 제외
        sim_index = sim_index[sim_index != target_item_index]

        result = pd.DataFrame()
        
        # Data Frame으로 만들고 vote_count로 정렬한 뒤 return
        result = df.iloc[sim_index].sort_values('itemname', ascending=False)[:8].copy() # 이부분 copy 추가
        
        return result

    recommendation_df = get_recommend_item_list(join_df, re_itemname)
    return recommendation_df
