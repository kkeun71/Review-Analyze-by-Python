import re
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from bs4 import BeautifulSoup
import time
import pymysql
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import UnexpectedAlertPresentException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from .category_class import category_load
from pymysql.constants import CLIENT


def crawling(URL) :

    conn = pymysql.connect(host='localhost',  # DB 연결
                            user='root',
                            password='1234',
                            db='abcds',
                            charset='utf8',
                            client_flag = CLIENT.MULTI_STATEMENTS,
                            )

    mycursor = conn.cursor() # DB 커서 생성
    
    # 브라우저 옵션 설정
    chrome_options = Options()
    chrome_options.add_experimental_option("detach", True)
    chrome_options.add_experimental_option("excludeSwitches", ["enable-logging"])
    chrome_options.add_experimental_option('useAutomationExtension', False)
    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"]) 
    prefs = {'profile.default_content_setting_values': {'cookies' : 2, 'images': 2, 'plugins' : 2, 'popups': 2, 'geolocation': 2, 'notifications' : 2, 'auto_select_certificate': 2, 'fullscreen' : 2, 'mouselock' : 2, 'mixed_script': 2, 'media_stream' : 2, 'media_stream_mic' : 2, 'media_stream_camera': 2, 'protocol_handlers' : 2, 'ppapi_broker' : 2, 'automatic_downloads': 2, 'midi_sysex' : 2, 'push_messaging' : 2, 'ssl_cert_decisions': 2, 'metro_switch_to_desktop' : 2, 'protected_media_identifier': 2, 'app_banner': 2, 'site_engagement' : 2, 'durable_storage' : 2}}   
    chrome_options.add_experimental_option('prefs', prefs)

    # driver 옵션 설정
    chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36')
    chrome_options.add_argument('--disable-blink-features=AutomationControlled')
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument('headless')

    # ChromeDriver 설치
    service = Service(executable_path=ChromeDriverManager().install()) 

    # 드라이버 생성
    driver = webdriver.Chrome(service = service, options = chrome_options)

    # 에러 처리
    try: 
        result = driver.switch_to_alert()
        result.accept()
        result.dismiss()

    except :
        "There is no alert"
                
    # 크롤링 방지 우회 설정
    driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument",
                        {"source" : """ Object.defineProperty(navigator, 'webdriver', {get :() => undefined}) """})
    
    
    # 쇼핑몰 구분하기 위한 정규표현식
    title = re.findall('11st|coupang|auction|naver|gmarket', URL)[0]
    print(title)

    if title == 'coupang' :
        try :  # 쿠팡 크롤링 실행시 자주 발생하는 드라이버 오류 예외처리
            driver.get(URL)

        except UnexpectedAlertPresentException : 
            driver.get(URL)

        # 상품평 버튼 추적 및 클릭
        WebDriverWait(driver,5).until(EC.presence_of_all_elements_located((By.NAME, "review")))
        reviews = driver.find_element(by = By.NAME, value = 'review')
        reviews.click()

        html = driver.page_source #페이지 로딩 끝나면 html 변수에 모든 페이지 소스 저장
        soup = BeautifulSoup(html, 'html.parser')
        time.sleep(1)

        # 리뷰 존재 유무 확인
        review_counts = soup.select('.product-tab-review-count')[0].text

        if review_counts == "" : # 리뷰 수 없을 시 None 리턴
            return None

        else :  # 리뷰 수 0개 아닐 시 리뷰 갯수 추출
            review_counts = int(re.sub(r'[^0-9]','', str(review_counts)))
        
        # DB 데이터 넣기 
            sql = "insert into craw (itemname, url ,review, img_url, star, category, re_star) values (%s ,%s ,%s ,%s ,%s, %s, %s)" 
            mycursor = conn.cursor() 

            # 상품명
            itemname = soup.select('.prod-buy-header__title')[0].text.replace("/","").replace(" ","_") 

            # 별점
            WebDriverWait(driver,5).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".sdp-review__average__total-star__info-orange")))
            star = driver.find_element(by = By.CSS_SELECTOR, value = '.sdp-review__average__total-star__info-orange').get_attribute('data-rating') 

            #카테고리
            category = soup.select('#breadcrumb > li:nth-child(2) > a')[0].text.strip()
            category = category_load(category)

            # 이미지
            img_url = driver.find_element(by = By.CSS_SELECTOR, value = 'img.prod-image__detail').get_attribute("src")

            #페이지 개수 찾기(리뷰 수가 적어서 다음 페이지 없는 제품은 예외처리 후 바로 크롤링)
            try :
                butnlist = driver.find_elements(By.CSS_SELECTOR, value = 'div.sdp-review__article__page')[0] # 버튼 나열한 div 추출
                butnlist = butnlist.find_elements(By.CSS_SELECTOR, value = 'button') # 추출한 div에서 모든 버튼 추출

                # 리뷰 페이지 개수 계산
                pagenum = review_counts // 5 // 10 

                def coupang_craw():
                    curpage = 2
                    lastpage = len(butnlist) - 1
                    index = 1
                    while curpage <= lastpage :
                            html = driver.page_source  # 페이지 내의 HTML 전체 정보 저장
                            soup = BeautifulSoup(html, 'html.parser') # 저장한 HTML 정보를 태그별로 분할해서 저장 
                            texts = soup.select('.sdp-review__article__list__review__content') # 해당 태그의 데이터 크롤링

                            # 크롤링된 전체 텍스트를 하나씩 데이터베이스에 commit하는 반복문
                            for i in texts :
                                review = i.text 
                                min_star = driver.find_element(by = By.XPATH, value = f'//*[@id="btfTab"]/ul[2]/li[2]/div/div[6]/section[4]/article[{index}]/div[1]/div[3]/div[1]/div').get_attribute('data-rating') 
                                min_star = float(min_star)
                                if min_star <= 5.0 and min_star >= 4.0:
                                    re_star = 1

                                elif min_star >= 0.0 and min_star < 4.0 :
                                    re_star = 0
                                if index == 5:
                                    index = 1
                                else:
                                    index += 1

                                mycursor.execute(sql,(itemname,URL,review,img_url,star,category,re_star)) # 변수 sql에 담겨있는 쿼리문 실행
                                conn.commit() # DB와 Commit

                            curpage += 1 # 현재 페이지를 다음페이지로 넘기기 위해서 숫자 올림
                            nextpage_num = driver.find_element(By.CSS_SELECTOR, value = '#btfTab > ul.tab-contents > li.product-review > div > div.sdp-review__article.js_reviewArticleContainer > section.js_reviewArticleListContainer > div.sdp-review__article__page.js_reviewArticlePagingContainer > button:nth-child({})'.format(curpage))
                            driver.execute_script("arguments[0].click();", nextpage_num)
                            del soup # 이전에 저장한  HTML 정보 삭제

                    if curpage == 11: # 11페이지까지 갔으면 다음 버튼 누르는거(1~10page -> 11~20page)
                            nextbtn = driver.find_element(By.CSS_SELECTOR, value = 'button.sdp-review__article__page__next')
                            driver.execute_script("arguments[0].click();", nextbtn)
                            curpage = 1

                # 리뷰 수에 따라 크롤링 횟수 조절
                if pagenum >= 10 :
                    for i in range(3):
                        coupang_craw()


                elif pagenum < 10 and pagenum > 0 :
                    for i in range(pagenum + 1):
                        coupang_craw()


                elif pagenum == 0 :
                    coupang_craw()

            # 예외 처리
            except : 
                html = driver.page_source 
                soup = BeautifulSoup(html, 'html.parser')
                texts = soup.select('.sdp-review__article__list__review__content')
                index = 1
                if len(texts) == 0: # 리뷰 없을 경우 None 반환
                    return None
                else : 
                    for i in texts :
                        review = i.text

                        # 감성 분석을 위한 각 리뷰에 평가된 별점 크롤링
                        min_star = driver.find_element(by = By.XPATH, value = f'//*[@id="btfTab"]/ul[2]/li[2]/div/div[6]/section[4]/article[{index}]/div[1]/div[3]/div[1]/div').get_attribute('data-rating') 
                        min_star = float(min_star)
                        if min_star <= 5.0 and min_star > 3.0:
                            re_star = 1

                        elif min_star >= 0.0 and min_star <= 3.0 :
                            re_star = 0
                        mycursor.execute(sql,(review,re_star)) # 변수 sql에 담겨있는 쿼리문 실행
                        conn.commit() # DB와 커밋
                        if index == 5:
                            index = 1
                        else:
                            index += 1

    # 11번가
    elif title == '11st' :
            print('11st')
            title_11st =  re.findall('11st|catalog.11st', URL)[0]
            
            # 셀레니움 크롤링
            driver.get(URL) 

            # 11번가(일반 리뷰)
            if title_11st == '11st' :  

                #쇼핑몰 구분하기 위한 정규표현식
                title = re.findall('11st|coupang', URL)

                # 상품명, 별점 등 가져오기 위해서 프레임 변경 전에 한번 html정보 읽어옴
                html = driver.page_source 
                soup = BeautifulSoup(html, 'html.parser')


                # 리뷰 유무 확인
                review_counts = soup.select('#tabMenuDetail2 > i')[0].text
                review_counts = int(re.sub(r'[^0-9]', '', str(review_counts)).replace(" ",""))

                # 리뷰 없을시 None 반환
                if review_counts == 0 : 
                    return None
                
                else : 
                    # DB 데이터 넣기 
                    sql = "insert into craw (itemname, url ,review, img_url, star, category, re_star) values (%s ,%s ,%s ,%s ,%s, %s, %s)" 
                    mycursor = conn.cursor() 

                    # 상품명
                    itemname = soup.select('h1.title')[0].text.replace("/","").replace('\n',"").replace(" ","_") 

                    # 이미지
                    img_url = driver.find_element(by = By.CSS_SELECTOR, value = '.img_full > img').get_attribute("src")

                    #카테고리 
                    category = soup.select('#layBodyWrap > div > div.s_product.s_product_detail > div.l_product_cont_wrap > div > div.l_product_view_wrap > div.c_product_category_path > ol > li:nth-child(2) > div > div.dropdown_selected')[0].text
                    category = category.strip().replace('카테고리 목록 열기','').replace('\n','')
                    category = category_load(category)

                    # 필요한 정보 저장 후 html정보 삭제
                    del soup

                    # 프레임 변경 있을때 사용(ex: 11번가) 
                    review_frame = driver.find_element(by = By.ID, value = "ifrmReview") 
                    driver.switch_to.frame(review_frame)

                    html = driver.page_source #페이지 로딩 끝나면 html 변수에 모든 페이지 소스 저장
                    soup = BeautifulSoup(html, 'html.parser')

                    try : 
                        star = driver.find_element(by = By.XPATH, value = '//*[@id="review-summary-area"]/div[2]/dl/dt/div/span[1]/em').text # 그냥 11번가 제품 별점
                    except :
                        star = driver.find_element(by = By.XPATH, value = '//*[@id="ar-tabpannel-review-2"]/div[1]/div/div/div[1]/span[2]/em').text # 11번가에서 파는 아마존 제품 별점
                    
                    try :
                        # 리뷰 페이지 개수 계산
                        pagenum = review_counts // 20

                        def st11_craw(num):
                            for i in range(num):
                                    WebDriverWait(driver,5).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, '#review-list-page-area > div > button')))
                                    nextbtn = driver.find_element(by = By.CSS_SELECTOR, value = '#review-list-page-area > div > button')
                                    driver.execute_script("arguments[0].click();", nextbtn)

                                        
                            html = driver.page_source #페이지 로딩 끝나면 html 변수에 모든 페이지 소스 저장
                            soup = BeautifulSoup(html, 'html.parser')

                            texts = soup.select('.cont_review_hide')
                            index = 1
                            s_index = 2
                            ul_index = 'ul'
                            for i in texts :
                                review = i.text

                                # 감성 분석을 위한 각 리뷰에 평가된 별점 크롤링
                                min_star = driver.find_element(by = By.CSS_SELECTOR, value = f"#review-list-page-area > {ul_index} > li:nth-child({index}) > div > p.grade > span > em").text
                                min_star = int(min_star)
                                if min_star <= 5 and min_star >= 4:
                                    re_star = 1

                                elif min_star >= 0 and min_star < 4 :
                                    re_star = 0
                                    
                                index += 1
                                if index == 20 :
                                    ul_index = f'ul:nth-child({s_index})'
                                    s_index += 1
                                    
                                    index = 1
                                mycursor.execute(sql,(itemname,URL,review,img_url,star,category,re_star)) # 변수 sql에 담겨있는 쿼리문 실행
                                conn.commit() # DB와 커밋
                            
                        # 리뷰 수에 따른 크롤링 횟수 조절
                        if pagenum >= 10 :
                            st11_craw(8)

                        elif pagenum < 10 and pagenum > 0 : 
                            st11_craw(pagenum)

                        elif pagenum == 0 : 
                            st11_craw(0)

                    except:
                        st11_craw(0)

        # 11번가 (비교가격)
            elif title_11st == 'catalog.11st' : 

                # 셀레니움 크롤링
                driver.get(URL)

                # 상품평 버튼 추적 및 클릭
                WebDriverWait(driver,5).until(EC.presence_of_all_elements_located((By.ID, "reviewLi")))
                reviews = driver.find_element(by = By.ID, value = 'reviewLi')
                reviews.click()

                html = driver.page_source #페이지 로딩 끝나면 html 변수에 모든 페이지 소스 저장
                soup = BeautifulSoup(html, 'html.parser')
                
                # 리뷰 유무 확인
                review_counts = soup.select('#reviewLi > a > em')[0].text
                
                # 리뷰 없을시 None 반환
                if review_counts == '':
                    return None

                else : 
                    # 리뷰 수만 추출(ex: (10) - > 10)
                    review_counts = int(re.sub(r'[^0-9]', '', str(review_counts)).replace(" ",""))

                    # DB 데이터 넣기 
                    sql = "insert into craw (itemname, url ,review, img_url, star, category, re_star) values (%s ,%s ,%s ,%s ,%s, %s, %s)" 
                    mycursor = conn.cursor() 

                    # 상품명
                    itemname = soup.select('div.heading > h2')[0].text.replace("/","").replace('\n',"").replace(" ","_") 

                    # 별점
                    star = soup.select('.num')[0].text

                    category = "None"

                    # 이미지 (이미지 태그가 2종류인 사이트가 있기 때문에 2종류 모두 크롤링 할 수 있도록 예외처리)
                    try:
                        img_url = driver.find_element(by = By.CSS_SELECTOR, value = '#productImg > ul > li > img').get_attribute("src")
                    except:
                        img_url = driver.find_element(by = By.CSS_SELECTOR, value = '#productImg > div.virtual-wrap > div > ul > li:nth-child(1) > img').get_attribute("src")
                
                    # 페이지 버튼 수(크롤링 회수 조절시 사용)
                    try : 
                        butnlist = driver.find_elements(By.CSS_SELECTOR, value = '#prdReviewPaging > span')[0] 
                        butnlist = len(butnlist.find_elements(By.CSS_SELECTOR, value = 'a')) + len(butnlist.find_elements(By.CSS_SELECTOR, value = 'strong'))

                        # 리뷰 페이지 개수 계산
                        pagenum = review_counts // 5

                        def st11_craw2():
                            curpage = 2
                            while curpage <= lastpage :
                                html = driver.page_source  
                                soup = BeautifulSoup(html, 'html.parser')
                                texts = soup.select('.summ_conts')
                                index = 1

                                for i in texts :
                                    review = i.text

                                     # 감성 분석을 위한 각 리뷰에 평가된 별점 크롤링
                                    min_star = driver.find_element(by = By.XPATH, value = f'//*[@id="reviewObj"]/dl/li[{index}]/div/div[1]/div[1]/div/p/span').text
                                    min_star =  int(re.sub(r'[^0-9]', '', min_star)[1])

                                    # 4점에서 5점까지는 1, 그 이하로는 0으로 반환
                                    if min_star <= 5 and min_star >= 4:
                                        re_star = 1
                                    elif min_star >= 0 and min_star < 4:
                                        re_star = 0
                                    index += 1
                                    # 한 페이지에 리뷰가 5개 있는데 5개 모두를 크롤링 하면 다음 페이지 리뷰 크롤링으로 넘어가도록 인덱스 조정
                                    if index == 6:
                                        index = 1
                                    mycursor.execute(sql,(itemname,URL,review,img_url,star,category,re_star)) # 변수 sql에 담겨있는 쿼리문 실행
                                    conn.commit() # DB와 커밋
                                            
                                nextpage_num = driver.find_element(By.CSS_SELECTOR, value = '#prdReviewPaging > span > a:nth-child({})'.format(curpage))
                                driver.execute_script("arguments[0].click();", nextpage_num)
                                curpage += 1 # 현재 페이지를 다음페이지로 넘기기 위해서 숫자 올림
                                del soup # 이전에 저장한  HTML 정보 삭제

                            if curpage == 11: # 10페이지까지 갔으면 다음 버튼 누르는거
                                nextbtn = driver.find_element(By.CSS_SELECTOR, value = '#prdReviewPaging > a')
                                driver.execute_script("arguments[0].click();", nextbtn)
                                curpage = 2

                        # 리뷰 수에 따른 크롤링 회수 설정      
                        if pagenum >= 10 :
                            lastpage = 10
                            for i in range(3):
                                st11_craw2()
                        
                        elif pagenum > 0 and pagenum < 10:
                            lastpage = butnlist
                            st11_craw2()

                        else:
                            texts = soup.select('.summ_conts')
                            for i in texts :
                                review = i.text

                                # 감성 분석을 위한 각 리뷰에 평가된 별점 크롤링
                                min_star = driver.find_element(by = By.XPATH, value = f'//*[@id="reviewObj"]/dl/li[{index}]/div/div[1]/div[1]/div/p/span').text
                                min_star =  int(re.sub(r'[^0-9]', '', min_star)[1])

                                # 4점에서 5점까지는 1, 그 이하로는 0으로 반환
                                if min_star <= 5 and min_star >= 4:
                                    re_star = 1

                                elif min_star >= 0 and min_star < 4:
                                    re_star = 0
                                index += 1

                                # 한 페이지에 리뷰가 5개 있는데 5개 모두를 크롤링 하면 다음 페이지 리뷰 크롤링으로 넘어가도록 인덱스 조정
                                if index == 6:
                                    index = 1
                                mycursor.execute(sql,(itemname,URL,review,img_url,star,category,re_star)) # 변수 sql에 담겨있는 쿼리문 실행
                                conn.commit() # DB와 커밋

                    # 크롤링 작동시 발생하는 예외처리
                    except:
                        texts = soup.select('.summ_conts')
                        for i in texts :
                            review = i.text
                            min_star = driver.find_element(by = By.XPATH, value = f'//*[@id="reviewObj"]/dl/li[{index}]/div/div[1]/div[1]/div/p/span').text
                            min_star =  int(re.sub(r'[^0-9]', '', min_star)[1])
                            if min_star <= 5 and min_star >= 4:
                                re_star = 1
                            elif min_star >= 0 and min_star < 4:
                                re_star = 0
                            index += 1
                            if index == 6:
                                index = 1
                            mycursor.execute(sql,(itemname,URL,review,img_url,star,category,re_star)) # 변수 sql에 담겨있는 쿼리문 실행
                            conn.commit() # DB와 커밋

    # G마켓
    elif title == 'gmarket' :

            # 셀레니움 크롤링
            driver.get(URL)

            # 상품평 버튼 추적 및 클릭
            WebDriverWait(driver,5).until(EC.presence_of_all_elements_located((By.XPATH, '//*[@id="container"]/div[6]/div[1]/ul/li[2]/a')))
            reviews = driver.find_element(by = By.XPATH, value = '//*[@id="container"]/div[6]/div[1]/ul/li[2]/a')
            reviews.send_keys(Keys.ENTER) 
            time.sleep(0.5)

            html = driver.page_source #페이지 로딩 끝나면 html 변수에 모든 페이지 소스 저장
            soup = BeautifulSoup(html, 'html.parser')

            # 리뷰 유무 확인
            review_counts = soup.select('#review-wrapper > h3 > span')[0].text
            
            # 리뷰 없을 시 None 반환
            if review_counts == '0':
                return None

            else : 
                # 리뷰 개수 추출 (ex: (10) -> 10)
                review_counts = int(re.sub(r'[^0-9]', '', str(review_counts)).replace(" ",""))

                # DB 데이터 넣기 
                sql = "insert into craw (itemname, url ,review, img_url, star, category, re_star) values (%s ,%s ,%s ,%s ,%s, %s, %s)" 
                mycursor = conn.cursor() 

                # 상품명
                itemname = soup.select('.itemtit')[0].text.replace("/","").replace(" ","_") 

                # 카테고리
                category = soup.select('body > div.location-navi > ul > li:nth-child(2) > a')[0].text
                
                # 카테고리 대분류가 빠른장보기일 경우 중분류로 크롤링 하도록 조건문 설정
                if category == '빠른장보기' :
                    category = soup.select('body > div.location-navi > ul > li:nth-child(3) > a')[0].text

                # 카테고리 분류 함수로 중분류를 대분류로 변경 
                category = category_load(category)


                # 별점
                star = soup.select('.sprite__vip')[0].text 
                star = int(re.sub(r'[^0-9]', '', str(star)))

                #gmarket은 리뷰당 별점 없기 때문에 not null 에러 방지용 변수
                re_star = 1

                # 이미지
                try : 
                    img_url = driver.find_element(by = By.XPATH, value = '//*[@id="container"]/div[3]/div[1]/div[1]/ul/li/a/img').get_attribute("src")
                except : 
                    img_url = driver.find_element(by = By.XPATH, value = '//*[@id="container"]/div[3]/div[1]/div[1]/ul/li[1]/a/img').get_attribute("src")

                # 페이지 버튼 수 (크롤링 회수 조절시 사용)
                try :
                    butnlist = driver.find_elements(By.CSS_SELECTOR, value = 'div.board_pagenation')[0] 
                    butnlist = butnlist.find_elements(By.CSS_SELECTOR, value = 'ul > li') 

                    # 리뷰 페이지 개수 계산
                    pagenum = int(driver.find_elements(By.XPATH, value = '//*[@id="text-pagenation-wrap"]/div[2]/span/em')[0].text)

                    def gmarket_craw():
                        curpage = 2
                        while curpage <= lastpage :
                                html = driver.page_source
                                soup = BeautifulSoup(html, 'html.parser')
                                texts = soup.select('#premium-wrapper p.con')
                                for i in texts :
                                    review = i.text 
                                    mycursor.execute(sql,(itemname,URL,review,img_url,star,category,star)) # 변수 sql에 담겨있는 쿼리문 실행
                                    conn.commit() # DB와 커밋
                                        
                                nextpage_num = driver.find_element(By.CSS_SELECTOR, value = '#premium-pagenation-wrap > div.board_pagenation > ul > li:nth-child({}) > a'.format(curpage))
                                driver.execute_script("arguments[0].click();", nextpage_num)
                                curpage += 1 # 현재 페이지를 다음페이지로 넘기기 위해서 숫자 올림
                                del soup # 이전에 저장한  HTML 정보 삭제

                    if pagenum > 10 : # 페이지 10개 넘어가는 경우
                        lastpage = 10

                        for i in range(3) :
                            gmarket_craw()

                    else : # 페이지 수가 10페이지 미만인 경우
                        lastpage = len(butnlist)

                        for i in range(pagenum) :
                            gmarket_craw()

                except :
                    html = driver.page_source  # 페이지 내의 HTML 전체 정보 저장
                    soup = BeautifulSoup(html, 'html.parser')
                    texts = soup.select('#premium-wrapper p.con')
                    for i in texts :
                        review = i.text 
                        mycursor.execute(sql,(itemname,URL,review,img_url,star,category,re_star)) # 변수 sql에 담겨있는 쿼리문 실행
                        conn.commit() # DB와 커밋

    # 옥션
    elif title == 'auction' :

            # 셀레니움 크롤링
            driver.get(URL)

            #쇼핑몰 구분하기 위한 정규표현식
            print(title)

            # 상품평 버튼 추적 및 클릭
            WebDriverWait(driver,5).until(EC.presence_of_all_elements_located((By.XPATH, '//*[@id="tap_moving_2"]/a')))
            reviews = driver.find_element(by = By.XPATH, value = '//*[@id="tap_moving_2"]/a')
            reviews.send_keys(Keys.ENTER)
            time.sleep(0.5)

            html = driver.page_source #페이지 로딩 끝나면 html 변수에 모든 페이지 소스 저장
            soup = BeautifulSoup(html, 'html.parser')

            # 리뷰 수 
            review_counts = soup.select('#spnTotalItemTalk_display')[0].text
            
            if review_counts == "0":
                return None

            else :
                review_counts = int(re.sub(r'[^0-9]', '', str(review_counts)).replace(" ",""))

                # DB 데이터 넣기 
                sql = "insert into craw (itemname, url ,review, img_url, star, category, re_star) values (%s ,%s ,%s ,%s ,%s, %s, %s)" 
                mycursor = conn.cursor() 

                itemname = soup.select('.itemtit')[0].text.replace("/","").replace(" ","_") # 상품명

                # 별점 
                star = driver.find_element(by = By.CSS_SELECTOR, value = '#sectionVipOverview > div > div.box__score > p').text 
                star = re.findall('\d+.\d+',star)[0] # 총 5점중 몇점~ 하는거에서 필요한 최종 점수만 빼왔음

                #카테고리
                category = soup.select('#locbar > div > div.loc > div:nth-child(2) > a')[0].text.strip().replace("더보기","")

                # 카테고리 대분류가 빠른장보기일 경우 중분류로 크롤링 하도록 조건문 설정
                if category == '빠른장보기':
                    category = soup.select('#locbar > div > div.loc > div:nth-child(3) > a')[0].text.strip().replace("더보기","")

                    # 카테고리 분류 함수로 중분류를 대분류로 변경 
                    category = category_load(category)

                else: 
                    # 카테고리 분류 함수로 중분류를 대분류로 변경 
                    category = category_load(category)

                
                # 이미지
                try : 
                    img_url = driver.find_element(by = By.CSS_SELECTOR, value = '#content > div.item-topinfowrap > div.item-topgallerywrap > div > div.box__viewer-container > ul > li.on > a > img').get_attribute("src")

                except :
                    img_url = driver.find_element(by = By.CSS_SELECTOR, value = '#content > div.item-topinfowrap > div.item-topgallerywrap > div > div > ul > li.on > a > img').get_attribute("src")

                try :
                    # 페이지 버튼 수(크롤링 회수 조절시 사용)
                    pagenum = soup.select('#divVipReview > div > div > span')[0].text
                    pagenum = int(re.sub(r'[^0-9]', '', str(pagenum)))

                    def auction_craw():
                        html = driver.page_source  
                        soup = BeautifulSoup(html, 'html.parser')
                        texts = soup.select('div.box__review-text .text')
                        index = 0
                        for i in texts :
                            review = i.text

                            # 감성 분석을 위한 각 리뷰에 평가된 별점 크롤링
                            min_star = soup.select('div.box__content > div.box__info > div.box__star > span > span.sprite__vip.image__star-fill')[index] # 댓글당 별점 가져오기
                            min_star = int(re.sub(r'[^0-9]', '', str(min_star)))
                            index += 1
                            if min_star <= 100 and min_star >= 80:
                                re_star = 1

                            elif min_star >= 0 and min_star < 80 :
                                re_star = 0
                            mycursor.execute(sql,(itemname,URL,review,img_url,star,category,re_star)) # 변수 sql에 담겨있는 쿼리문 실행
                            conn.commit() # DB와 커밋
                        del soup # 이전에 저장한  HTML 정보 삭제

                        nextbtn = driver.find_element(By.CSS_SELECTOR, value = '#divVipReview > div > a.link__page-move')
                        driver.execute_script("arguments[0].click();", nextbtn)
                        time.sleep(0.5)

                    if pagenum >= 10 :
                            for i in range(6):
                                auction_craw()

                    elif pagenum > 1 and pagenum < 10:
                            for i in range(pagenum):
                                auction_craw()
                
                    else :
                        auction_craw()

                except :
                    html = driver.page_source  
                    soup = BeautifulSoup(html, 'html.parser')
                    texts = soup.select('div.box__review-text .text')
                    for i in texts :
                        review = i.text
                        mycursor.execute(sql,(itemname,URL,review,img_url,star,category,re_star)) # 변수 sql에 담겨있는 쿼리문 실행
                        conn.commit() # DB와 커밋

    return itemname