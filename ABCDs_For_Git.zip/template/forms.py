from django import forms

class CoverForm(forms.Form):
    url = forms.URLField() # 입력한 url을 텍스트 형식에서 url 형식으로 변형