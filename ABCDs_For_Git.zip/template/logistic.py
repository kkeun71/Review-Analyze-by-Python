# 패키지 설치
import pandas as pd
import pymysql
#warning 메시지 표시 안함
import warnings
warnings.filterwarnings(action = 'ignore')
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression # 이진 분류 알고리즘
from sklearn.model_selection import GridSearchCV # 하이퍼 파라미터 최적화
from sklearn.metrics import accuracy_score
import re # 정규식을 사용하기 위해 re 모듈을 임포트
import joblib
import os
from konlpy.tag import Okt # 형태소 분석에 사용할 konlpy 패키지의 Okt 클래스를 임포트하고 okt
from pymysql.constants import CLIENT
import openpyxl


def logistic(itemname,tfv) :
    okt = Okt()

    conn = pymysql.connect(host='localhost',
                    user='root',
                    port=3306,
                    password='1234',
                    db='abcds',
                    charset='utf8mb4',
                    autocommit=True,
                    client_flag = CLIENT.MULTI_STATEMENTS, 
                    )

    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    ############################### 이 부분은 학습된 모델 생성시에만 필요하기에 평소에는 주석처리##################################
    # train_df = pd.read_excel(BASE_DIR + '\\template\\test_user.xlsx') 


    # 데이터 확인
    # print(train_df.head())

    # # 댓글이 있는 항목만 담기(빈 댓글 삭제)
    # # text 컬럼이 non-null인 샘플만 train_df에 다시 저장
    # train_df = train_df[train_df['review'].notnull()]

    # # 수정된 train_df의 정보를 다시 확인
    # print(train_df.info())

    # # 분류 클래스의 구성을 확인
    # print(train_df['re_star'].value_counts())

    # # 한글 외 문자 제거(옵션)
    # # ‘ㄱ ~‘힣’까지의 문자를 제외한 나머지는 공백으로 치환, 영문: a-z| A-Z
    # train_df['review'] = train_df['review'].apply(lambda x : re.sub(r'[^ ㄱ-ㅣ가-힣]+', " ", x))
    # print(train_df.head())

    # # Train용 데이터셋의 정보를 재확인
    # print(train_df.info())
    # text = train_df['review'] # 시리즈 객체로 저장
    # score = train_df['re_star']

    # train_x, test_x, train_y, test_y = train_test_split(text, score , test_size=0.2, random_state=0)
    # print(len(train_x), len(train_y), len(test_x), len(test_y))

    # tfv = TfidfVectorizer(tokenizer=okt.morphs, ngram_range=(1,2), min_df=3, max_df=0.9)
    # tfv.fit(train_x)
    # tfv_train_x = tfv.transform(train_x)
    # print(tfv_train_x)

######################################################################################################################

    grid_cv = joblib.load(BASE_DIR + "/template/emotional.pkl") ## 모델 불러오기

    text_sql = "SELECT review FROM craw where itemname = %s" # DB에서 리뷰 load
    cursor = conn.cursor()
    cursor.execute(text_sql,itemname) # itemname을 인자로한 sql 실행

    input_text = cursor.fetchall() # 실행된 SQL을 통해 모든 리뷰를 load
    cursor.close()
    conn.close() # DB 연결 종료
    
    # 긍정, 부정 수치를 나타낼 변수 선언
    positive = 0
    negative = 0

    for i in range(len(input_text)) :
    #입력 텍스트에 대한 전처리 수행
        texts = re.compile(r'[ㄱ-ㅣ가-힣]+').findall(input_text[i][0])
        texts = [" ".join(texts)]
        # 입력 텍스트의 피처 벡터화
        st_tfidf = tfv.transform(texts)

        # 최적 감성 분석 모델에 적용하여 감성 분석 평가
        st_predict = grid_cv.best_estimator_.predict(st_tfidf)
        
        #예측 결과 출력
        if(st_predict[0] == 0):
            negative = negative + 1
        elif(st_predict[0] == 1):
            positive = positive + 1

    # 계산된 긍정 ,부정 수치를 변수에 저장 
    positive = str(round((positive / len(input_text) * 100),1)) + "%"
    negative = str(round((negative / len(input_text) * 100),1)) + "%"

    #저장된 변수 서버로 전송
    return positive, negative
    