import pymysql

def pre_test(url):
    conn = pymysql.connect(host='localhost',
                            user='root',
                            password='1234',
                            db='abcds',
                            charset='utf8')

    sql = "select url from craw"
    cursor = conn.cursor()

    cursor.execute(sql)
    res = cursor.fetchall()

    for i in range(len(res)):
        if url in res[i][0]:
            result = True
            if result == True:
                break
            else :
                continue
        else:
            result = False
            
    print(result)
    return result
