import pymysql

# 이전 검색 리스트를 검색하기 위해 가장 최근 검색한 이미지 추출하는 함수
def previous_search_list():
    conn = pymysql.connect(host='localhost',
                            user='root',
                            password='1234',
                            db='abcds',
                            charset='utf8')

    sql = "select img_url from keyword order by id desc limit 0,4"
    cursor = conn.cursor()

    cursor.execute(sql)
    res = cursor.fetchall()

    imgurl_list = []

    # 이전에 검색한 제품의 이미지를 DB에서 Load 후 반환
    for i in range(len(res)):
        imgurl_list.append(res[i][0])
    
    return imgurl_list