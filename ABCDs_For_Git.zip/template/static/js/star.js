var rating = $('.product_item_name');

rating.each(function(){
	var $this = $(this);
	var targetScore = $this.attr('data-rate');
	var firstdigit = targetScore.split('.');
	console.log(firstdigit);
		if(firstdigit.length > 1){
			for(var i = 0; i < targetScore[0]; i++){
			$this.find('.star').eq(i).css({width:'100%'});
			}
			$this.find('.star').eq(firstdigit[0]).css({width:firstdigit[1] + '0%'});
		}else{
			for(var i = 0; i < targetScore; i++){
			$this.find('.star').eq(i).css({width:'100%'});
			}
		}
});