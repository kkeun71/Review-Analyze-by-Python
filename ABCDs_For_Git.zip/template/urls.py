from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name = "home"), # 메인 페이지 라우팅
    path('search/', views.search),
    path('previous_1/', views.previous_1, name="previous_1"),
    path('previous_2/', views.previous_2, name="previous_2"),
    path('previous_3/', views.previous_3, name="previous_3"),
    path('previous_4/', views.previous_4, name="previous_4"),
    path('repage_1/', views.repage_1, name="repage_1"),
    path('repage_2/', views.repage_2, name="repage_2"),
    path('repage_3/', views.repage_3, name="repage_3"),
    path('repage_4/', views.repage_4, name="repage_4"),
    path('repage_5/', views.repage_5, name="repage_5"),
    path('repage_6/', views.repage_6, name="repage_6"),
    path('repage_7/', views.repage_7, name="repage_7"),
    path('repage_8/', views.repage_8, name="repage_8"),
    ]

