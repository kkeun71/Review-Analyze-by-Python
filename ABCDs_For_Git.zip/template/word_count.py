import pymysql
import pandas as pd
from wordcloud import WordCloud
from typing import Counter
import matplotlib.pyplot as plt
import os
import matplotlib


def count(itemname):
    conn = pymysql.connect(host='localhost',
                           user='root',
                           password='1234',
                           db='abcds',
                           charset='utf8')

    matplotlib.use('Agg')

    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    sql = "select keyword, counts from keyword where itemname = %s"
    cursor = conn.cursor()

    cursor.execute(sql, itemname)
    res = cursor.fetchall()

    word = res[0][0]
    count = res[0][1]

    word_list = word.split()
    count_list = count.split()

    wc_df = pd.DataFrame(
        data=list(zip(word_list, count_list)), columns=['word', 'count'])
    print(wc_df)

    font_path = "C:/Windows/Fonts/malgun.ttf"  # 워드클라우드 때문에 사용 - 폰트 경로 개별적으로 바꿀 것

    word_dic = Counter(word_list)
    wc = WordCloud(width=600, height=600,
                   background_color='white', font_path=font_path)
    plt.imshow(wc.generate_from_frequencies(word_dic))
    plt.axis("off")
    plt.savefig(
    BASE_DIR+f'/template/static/img/wordcloud/{itemname}.png', dpi=200)
    plt.close()
